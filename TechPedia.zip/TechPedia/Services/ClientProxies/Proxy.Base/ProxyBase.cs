﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Xml.Linq;
using System.IO;
using App.TechPedia.Common;
namespace Proxy.Base
{
    public class ProxyBase : IProxy
    {
        public object VendorComponent;
        public XElement VendorConfiguration;

        public virtual void SetConfiguration(XElement vendorConfiguration)
        {
            VendorConfiguration = vendorConfiguration;
            CreateVendorComponent();
        }

        public virtual IEnumerable<XElement> SearchItem(string[] parameters)
        {
            if (VendorComponent == null)
                return null;

            object returnitem = VendorComponent.GetType().InvokeMember("SearchItem", BindingFlags.InvokeMethod, null, VendorComponent, new object[] { parameters });

            if (returnitem != null)
                return returnitem as IEnumerable<XElement>;

            return null;
        }

        public virtual XElement GetItem(string itemID)
        {
            if (VendorComponent == null)
                return null;

            object item = VendorComponent.GetType().InvokeMember("GetItem", BindingFlags.InvokeMethod, null, VendorComponent, new object[] { itemID });

            return item as XElement;
        }

        public virtual XElement GetOrderList()
        {
            if (VendorComponent == null)
                return null;

            object item = VendorComponent.GetType().InvokeMember("GetOrderList", BindingFlags.InvokeMethod, null, VendorComponent, null);

            return item as XElement;
        }

        public virtual XElement GetOrder(string orderID)
        {
            if (VendorComponent == null)
                return null;

            object item = VendorComponent.GetType().InvokeMember("GetOrder", BindingFlags.InvokeMethod, null, VendorComponent, new object[] { orderID });

            return item as XElement;    
        }

        public virtual XElement PlaceOrder(XElement parameters)
        {
            if (VendorComponent == null)
                return null;

            object item = VendorComponent.GetType().InvokeMember("PlaceOrder", BindingFlags.InvokeMethod, null, VendorComponent, new object[] { parameters });

            return item as XElement;
        }

        public virtual string QueryOrderStatus(string orderID, string itemID)
        {
            if (VendorComponent == null)
                return null;

            object item = VendorComponent.GetType().InvokeMember("QueryOrderStatus", BindingFlags.InvokeMethod, null, VendorComponent, new object[] { orderID, itemID });

            return item.ToString();
        }

        public virtual void CancelOrder(string orderID, string itemID)
        {
            if (VendorComponent == null)
                return;

            object item = VendorComponent.GetType().InvokeMember("CancelOrder", BindingFlags.InvokeMethod, null, VendorComponent, new object[] { orderID, itemID });
        }

        protected virtual void CreateVendorComponent()
        {
            XAttribute temp = VendorConfiguration.Attribute("assemblyname");
            string temp2 = Path.GetFileNameWithoutExtension(temp.Value);
            string temp1 = Path.Combine(CommonFunctions.GetAppPath(), "Vendors");
            temp1 = Path.Combine(temp1, temp2);
            string assemblyName = Path.Combine(temp1, temp.Value);

            temp = VendorConfiguration.Attribute("classname");
            string className = temp.Value;

            Assembly assembly = Assembly.LoadFile(assemblyName);

            Type classType = assembly.GetTypes().FirstOrDefault(pred => pred.Name.Trim().ToUpper() == className.Trim().ToUpper());

            VendorComponent = Activator.CreateInstance(classType);

            VendorComponent.GetType().InvokeMember("SetVendorID", BindingFlags.InvokeMethod, null, VendorComponent, new object[] { VendorConfiguration.GetAttribute("id") });
        }
    }
}
