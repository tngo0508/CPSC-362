﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using App.TechPedia.Common;

namespace App.TechPedia.DataAccessLayer
{
    public static class DataAccessLayer
    {
        private static XElement Vendors;
        private static XElement Users;
        private static XElement Carts;

        public static XElement GetVendors()
        {
            if (Vendors == null)
            {
                string vendorFileName = GetVendorsFile();

                Vendors = XElement.Load(vendorFileName);
            }

            return Vendors;
        }

        public static XElement GetUsers()
        {
            if (Users == null)
            {
                string userFileName = GetUserFile();

                Users = XElement.Load(userFileName);
            }

            return Users;
        }

        public static XElement GetCarts()
        {
            if (Carts == null)
            {
                string cartFile = GetCartFile();

                if (File.Exists(cartFile))
                {
                    Carts = XElement.Load(cartFile);
                }
                else
                {
                    Carts = new XElement("cart");
                    Carts.Save(cartFile);
                }
            }

            return Carts;
        }

        public static XElement GetOrderList()
        {
            string workingFolder = GetOrderFolder();

            XElement returnItem = new XElement("orderlist");

            string[] files = Directory.GetFiles(workingFolder, "*.xml", SearchOption.TopDirectoryOnly);

            foreach (string file in files)
            {
                XElement item = new XElement("item", new XAttribute("order", Path.GetFileNameWithoutExtension(file)));
                returnItem.Add(item);
            }

            return returnItem;
        }

        public static void SaveVendors()
        {
            string fileName = GetVendorsFile();

            GetVendors().Save(fileName);
        }

        public static void SaveUsers()
        {
            string fileName = GetUserFile();

            GetUsers().Save(fileName);
        }

        public static void SaveCarts()
        {
            string fileName = GetCartFile();

            GetCarts().Save(fileName);
        }

        public static XElement GetUser(string userID)
        {
            XElement user = GetUsers().Elements("user").FirstOrDefault(pred => pred.GetAttribute("id").Trim().ToUpper() == userID.Trim().ToUpper());

            return user;
        }

        public static void RemoveFromCart(string vendorid, string itemID)
        {
            XElement cartElement = GetCarts();

            XElement item = cartElement.Elements("item").FirstOrDefault(pred => pred.GetAttribute("vendorid").Trim().ToUpper() == vendorid.Trim().ToUpper() && pred.GetAttribute("itemid").Trim().ToUpper() == itemID.Trim().ToUpper());

            if (item != null)
                item.Remove();

            cartElement.Save(GetCartFile());
        }

        public static void UpdateCart(string vendorid, string itemID, double qty)
        {
            XElement cartElement = GetCarts();

            XElement item = cartElement.Elements("item").FirstOrDefault(pred => pred.GetAttribute("vendorid").Trim().ToUpper() == vendorid.Trim().ToUpper() && pred.GetAttribute("itemid").Trim().ToUpper() == itemID.Trim().ToUpper());

            if (item != null)
                item.SetAttributeValue("qty", qty.ToString());

            cartElement.Save(GetCartFile());
        }

        public static void AddToCart(string vendorid, string itemID, int qty)
        {
            XElement cartElement = GetCarts();

            XElement cartItem = new XElement("item", new XAttribute("vendorid", vendorid),
                                                     new XAttribute("itemid", itemID),
                                                     new XAttribute("qty", qty)
                                            );

            cartElement.Add(cartItem);

            cartElement.Save(GetCartFile());
        }
        
        public static void PlaceOrder(XElement element)
        {
            string orderID = element.GetAttribute("orderid");

            string orderFileName = GetOrderFileName(orderID);

            element.Save(orderFileName);
        }
        
        public static XElement GetOrder(string orderID)
        {
            string fileName = GetOrderFileName(orderID);

            XElement order = XElement.Load(fileName);

            return order;
        }

        public static void CancelOrder(string orderID, string vendorID, string itemID)
        {
            string fileName = GetOrderFileName(orderID);

            XElement order = XElement.Load(fileName);

            if (order == null)
                return;

            XElement item = order.Elements("item").FirstOrDefault(pred => pred.GetAttribute("vendorid").Trim().ToUpper() == vendorID.Trim().ToUpper() && pred.GetAttribute("itemid").Trim().ToUpper() == itemID.Trim().ToUpper());

            if (item != null)
            {
                item.SetAttributeValue("status", "Order Cancelled");
                item.SetAttributeValue("qty", "0");
                order.Save(fileName);
            }
        }

        private static string GetUserFile()
        {
            string fileName = Path.Combine(CommonFunctions.GetAppPath(), "Users.xml");

            if (!File.Exists(fileName))
            {
                XElement element = new XElement("users");
                XElement adminUser = new XElement("user", new XAttribute("id", "admin"),
                                                          new XAttribute("password", "admin"),
                                                          new XAttribute("firstname", "admin"),
                                                          new XAttribute("lastname", "admin"),
                                                          new XAttribute("isadmin", "true"),
                                                          new XAttribute("isactive", "true")
                                                 );
                element.Add(adminUser);
                element.Save(fileName);
            }

            return fileName;
        }
        
        private static string GetVendorsFile()
        {
            string fileName = Path.Combine(CommonFunctions.GetAppPath(), "Vendors.xml");

            if (!File.Exists(fileName))
            {
                XElement element = new XElement("vendors");
                element.Save(fileName);
            }

            return fileName;
        }

        private static string GetCartFile()
        {
            string workingFolder = GetUserWorkingFolder();

            if (!Directory.Exists(workingFolder))
                Directory.CreateDirectory(workingFolder);

            string fileName = Path.Combine(workingFolder, "Carts.xml");

            if (!File.Exists(fileName))
            {
                XElement element = new XElement("carts");
                element.Save(fileName);
            }

            return fileName;
        }

        private static string GetOrderFileName(string orderID)
        {
            string workingFolder = GetOrderFolder();

            string fileName = Path.Combine(workingFolder, orderID + ".xml");

            if (!File.Exists(fileName))
            {
                XElement element = new XElement("orders");
                element.Save(fileName);
            }

            return fileName;
        }

        private static string GetOrderFolder()
        {
            string workingFolder = GetUserWorkingFolder();

            if (!Directory.Exists(workingFolder))
                Directory.CreateDirectory(workingFolder);

            workingFolder = Path.Combine(workingFolder, "orders");

            if (!Directory.Exists(workingFolder))
                Directory.CreateDirectory(workingFolder);

            return workingFolder;
        }

        private static string GetUserWorkingFolder()
        {
            string loggedInUserID = CommonFunctions.CurrentLoggedInUser.GetAttribute("id");

            string folder = Path.Combine(CommonFunctions.GetAppPath(), loggedInUserID);

            return folder;
        }
    }
}
