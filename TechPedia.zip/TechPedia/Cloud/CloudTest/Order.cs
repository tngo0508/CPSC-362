﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using DevExpress.XtraEditors.Repository;
using App.TechPedia.Common;
using App.TechPedia.DataAccessLayer;
namespace CloudTest
{
    public partial class Order : Form
    {
        public Order()
        {
            InitializeComponent();
        }

        private IProxy m_proxy = null;
        private XElement m_OrderItem = null;
        private RepositoryItemComboBox m_Edit = null;

        private void Order_Load(object sender, EventArgs e)
        {
            IEnumerable<XElement> vendorList = DataAccessLayer.GetVendors().Elements("vendor");

            cmbChooseVendor.Items.Clear();
            foreach (XElement vendor in vendorList)
            {
                cmbChooseVendor.Items.Add(vendor.GetAttribute("name"));
            }

            if (cmbChooseVendor.Items.Count > 0)
                cmbChooseVendor.SelectedIndex = 0;
        }

        private void cmbChooseVendor_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_proxy = null;

            XElement vendor = DataAccessLayer.GetVendors().Elements("vendor").FirstOrDefault(pred => pred.GetAttribute("name").Trim().ToUpper()
                                                                                                        == cmbChooseVendor.SelectedItem.ToString().Trim().ToUpper());

            if (vendor != null)
                m_proxy = CommonFunctions.GetVendorProxy(vendor);

            LoadOrders(vendor);
        }

        private void LoadOrders(XElement vendor)
        {
            if (m_proxy != null)
            {
                XElement orderItem = m_proxy.GetOrderList();

                IEnumerable<XElement> items = orderItem.Elements("item");

                lstOrder.Items.Clear();
                gridControl1.DataSource = null;
                foreach (XElement order in items)
                {
                    string orderID = order.GetAttribute("order");
                    string[] temp = orderID.Split('_');
                    lstOrder.Items.Add(temp[1]);
                }

                if (lstOrder.Items.Count > 0)
                    lstOrder.SelectedIndex = 0;
            }

        }

        private void lstOrder_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (m_proxy == null)
                return;

            m_OrderItem = m_proxy.GetOrder(lstOrder.SelectedItem.ToString());

            IEnumerable<XElement> orderItemList = m_OrderItem.Elements("item");
            IEnumerable<XElement> vendorList = DataAccessLayer.GetVendors().Elements("vendor");

            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("VendorID", typeof(string));
            dataTable.Columns.Add("Vendor", typeof(string));
            dataTable.Columns.Add("Item ID", typeof(string));
            dataTable.Columns.Add("Name", typeof(string));
            dataTable.Columns.Add("Price", typeof(string));
            dataTable.Columns.Add("Description", typeof(string));
            dataTable.Columns.Add("Qty", typeof(double));
            dataTable.Columns.Add("Status", typeof(string));
            dataTable.Columns.Add("element", typeof(XElement));

            foreach (XElement orderItem in orderItemList)
            {
                DataRow dataRow = dataTable.NewRow();

                XElement vendor = vendorList.FirstOrDefault(pred => pred.GetAttribute("id").Trim().ToUpper() == orderItem.GetAttribute("vendorid").Trim().ToUpper());

                if (vendor != null)
                {
                    XElement productItem = m_proxy.GetItem(orderItem.GetAttribute("itemid"));

                    dataRow[0] = orderItem.GetAttribute("vendorid");
                    dataRow[1] = vendor.GetAttribute("name");
                    dataRow[2] = orderItem.GetAttribute("itemid");
                    dataRow[3] = productItem.GetAttribute("name");
                    dataRow[4] = orderItem.GetAttribute("price");
                    dataRow[5] = productItem.GetAttribute("description");
                    dataRow[6] = orderItem.GetAttribute("qty");
                    dataRow[7] = string.IsNullOrEmpty(orderItem.GetAttribute("status")) ? "Order Received" : orderItem.GetAttribute("status");
                    dataRow[8] = orderItem;

                    dataTable.Rows.Add(dataRow);
                }
            }

            gridControl1.DataSource = dataTable;

            gridView1.Columns[0].Visible = false;
            gridView1.Columns[1].OptionsColumn.AllowEdit = false;
            gridView1.Columns[2].OptionsColumn.AllowEdit = false;
            gridView1.Columns[3].OptionsColumn.AllowEdit = false;
            gridView1.Columns[4].OptionsColumn.AllowEdit = false;
            gridView1.Columns[5].OptionsColumn.AllowEdit = false;
            gridView1.Columns[6].OptionsColumn.AllowEdit = false;
            gridView1.Columns[7].OptionsColumn.AllowEdit = true;
            gridView1.Columns[8].OptionsColumn.AllowEdit = false;
            gridView1.Columns[8].Visible = false;

            m_Edit = new RepositoryItemComboBox();
            m_Edit.Items.Add("Order Received");
            m_Edit.Items.Add("Processing");
            m_Edit.Items.Add("Shipped");
            m_Edit.Items.Add("Delivered");
            m_Edit.SelectedValueChanged += M_Edit_SelectedValueChanged;
            gridView1.Columns[7].ColumnEdit = m_Edit;

            gridControl1.Refresh();
        }

        private void M_Edit_SelectedValueChanged(object sender, EventArgs e)
        {
            DataRow dataRow = gridView1.GetFocusedDataRow();

            XElement orderElement = dataRow[8] as XElement;

            orderElement.SetAttributeValue("status", ((DevExpress.XtraEditors.TextEdit)sender).Text);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (m_OrderItem == null || m_proxy == null)
                return;

            m_proxy.PlaceOrder(m_OrderItem);

            MessageBox.Show("Order Saved.", CommonFunctions.GetCaption(), MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
