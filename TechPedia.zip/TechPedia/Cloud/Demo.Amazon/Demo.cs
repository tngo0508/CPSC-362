﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Drawing;
using System.Reflection;
using System.IO;
using App.TechPedia.Common;
namespace Demo.Amazon
{
    public class Demo
    {
        private string VendorID = string.Empty;

        public void SetVendorID(string vendorID)
        {
            VendorID = vendorID;
        }

        public virtual XElement GetInventory()
        {
            string folderName = GetWorkingFolder();
            string fileName = Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().Location) + ".xml";
            fileName = Path.Combine(folderName, fileName);

            XElement returnItem = XElement.Load(fileName);
            return returnItem;
        }

        public virtual IEnumerable<XElement> SearchItem(string[] arrParameters)
        {
            string category = arrParameters[0];
            string item = arrParameters[1];
            string brand = arrParameters[2];

            XElement inventory = GetInventory();
            IEnumerable<XElement> returnList = null;

            if (string.IsNullOrEmpty(category))
            {
                returnList = inventory.Descendants("item");
            }
            else
            {
                XElement element1 = inventory.Elements().FirstOrDefault(pred => pred.Name.LocalName.Trim().ToUpper() == category.Trim().ToUpper());
                if (string.IsNullOrEmpty(item))
                {
                    returnList = element1.Descendants("item");
                }
                else
                {
                    XElement element2 = element1.Elements().FirstOrDefault(pred => pred.Name.LocalName.Trim().ToUpper() == item.Trim().ToUpper());

                    if(string.IsNullOrEmpty(brand))
                    {
                        if(element2 != null)
                            returnList = element2.Descendants("item");
                    }
                    else
                    {
                        XElement element3 = element2.Elements().FirstOrDefault(pred => pred.Name.LocalName.Trim().ToUpper() == brand.Trim().ToUpper());
                        if(element3 != null)
                            returnList = element3.Descendants("item");
                    }
                }
            }

            return returnList;
        }

        public virtual XElement GetItem(string itemID)
        {
            XElement inventory = GetInventory();

            return inventory.Descendants("item").FirstOrDefault(pred => pred.GetAttribute("itemid").Trim().ToUpper() == itemID.Trim().ToUpper());
        }

        public virtual void PlaceOrder(XElement order)
        {
            string orderID = order.GetAttribute("orderid");

            string fileName = GetOrderFileName(orderID);

            order.Save(fileName);
        }

        public virtual string QueryOrderStatus(string orderID, string itemID)
        {
            string orderFile = GetOrderFileName(orderID);
            string status = "Order not yet received";

            if (File.Exists(orderFile))
            {
                status = "Order Received";

                XElement order = XElement.Load(orderFile);

                XElement item = order.Elements("item").FirstOrDefault(pred => pred.GetAttribute("itemid").Trim().ToUpper() == itemID.Trim().ToUpper());

                if (item != null)
                {
                    if(!string.IsNullOrEmpty(item.GetAttribute("status")))
                        status = item.GetAttribute("status");
                }
            }

            return status;
        }

        public virtual void CancelOrder(string orderID, string itemID)
        {
            string orderFile = GetOrderFileName(orderID);

            if (File.Exists(orderFile))
            {
                XElement order = XElement.Load(orderFile);

                XElement item = order.Elements("item").FirstOrDefault(pred => pred.GetAttribute("itemid").Trim().ToUpper() == itemID.Trim().ToUpper());

                if (item != null)
                {
                    item.SetAttributeValue("status", "Order Cancelled");
                    item.SetAttributeValue("qty", "0");

                    order.Save(orderFile);
                }
            }
        }

        public virtual XElement GetOrderList()
        {
            string workingFolder = GetOrderFolder();
            XElement returnItem = new XElement("orderlist");

            string[] files = Directory.GetFiles(workingFolder, VendorID + "_*.xml", SearchOption.TopDirectoryOnly);

            foreach (string file in files)
            {
                XElement item = new XElement("item", new XAttribute("order", Path.GetFileNameWithoutExtension(file)));
                returnItem.Add(item);
            }

            return returnItem;
        }

        public virtual XElement GetOrder(string orderID)
        {
            string fileName = GetOrderFileName(orderID);

            XElement order = XElement.Load(fileName);

            return order;
        }

        private string GetOrderFileName(string orderID)
        {
            string workingFolder = GetOrderFolder();
            string fileName = VendorID + "_" + orderID + ".xml";


            return Path.Combine(workingFolder, fileName);

        }

        private string GetWorkingFolder()
        {
            return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        }

        private string GetOrderFolder()
        {
            string workingFolder = GetWorkingFolder();

            workingFolder = Path.Combine(workingFolder, "order");

            if (!Directory.Exists(workingFolder))
                Directory.CreateDirectory(workingFolder);

            return workingFolder;
        }
    }
}
