﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml;
using System.IO;
using DevExpress.XtraEditors.Repository;
using App.TechPedia.Common;
using App.TechPedia.DataAccessLayer;
namespace App.TechPedia
{
    public partial class Vendors : Form
    {
        private XElement m_Vendors;
        private DataTable m_DataTable;

        public Vendors()
        {
            InitializeComponent();
        }

        private void Config_Load(object sender, EventArgs e)
        {
            CommonFunctions.SetFormInfo(this);

            BuildTable();
        }

        public void BuildTable()
        {
            m_Vendors = DataAccessLayer.DataAccessLayer.GetVendors();

            m_DataTable = new DataTable();

            m_DataTable.Columns.Add("ID", typeof(string));
            m_DataTable.Columns.Add("Name", typeof(string));
            m_DataTable.Columns.Add("Assembly Name", typeof(string));
            m_DataTable.Columns.Add("Class Name", typeof(string));
            m_DataTable.Columns.Add("Proxy Assembly Name", typeof(string));
            m_DataTable.Columns.Add("Proxy Class Name", typeof(string));
            m_DataTable.Columns.Add("Is Active", typeof(bool));

            IEnumerable<XElement> vendorLst = m_Vendors.Elements("vendor");

            foreach (XElement vendor in vendorLst)
            {
                DataRow dataRow = m_DataTable.NewRow();

                dataRow[0] = vendor.GetAttribute("id");
                dataRow[1] = vendor.GetAttribute("name");
                dataRow[2] = vendor.GetAttribute("assemblyname");
                dataRow[3] = vendor.GetAttribute("classname");
                dataRow[4] = vendor.GetAttribute("proxyassemblyname");
                dataRow[5] = vendor.GetAttribute("proxyclassname");
                dataRow[6] = CommonFunctions.ConvertToBool(vendor.GetAttribute("isactive"), true);

                m_DataTable.Rows.Add(dataRow);
            }

            gridControl1.DataSource = m_DataTable;

            gridView1.Columns[0].OptionsColumn.AllowEdit = false;
            gridView1.Columns[0].Visible = false;
        }

        private void btnNewRow_Click(object sender, EventArgs e)
        {
            if (m_DataTable != null)
            {
                DataRow dataRow = m_DataTable.NewRow();
                dataRow[0] = Guid.NewGuid().ToString();
                dataRow[3] = "Demo";
                dataRow[4] = "Proxy.Base.dll";
                dataRow[5] = "ProxyBase";
                dataRow[6] = true;
                m_DataTable.Rows.Add(dataRow);
            }

            gridControl1.RefreshDataSource();
            gridControl1.Refresh();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            foreach (DataRow dataRow in m_DataTable.Rows)
            {
                XElement vendor = m_Vendors.Elements("vendor").FirstOrDefault(pred => pred.GetAttribute("id").Trim().ToUpper() == dataRow[0].ToString().Trim().ToUpper());

                if (string.IsNullOrEmpty(dataRow[1].ToString()))
                {
                    MessageBox.Show("Data unfullfilled " + dataRow[0].ToString() + ".", CommonFunctions.GetCaption(), MessageBoxButtons.OK, MessageBoxIcon.Error);
                    continue;
                }

                if (vendor == null)
                {
                    vendor = new XElement("vendor");

                    m_Vendors.Add(vendor);
                }

                vendor.SetAttributeValue("id", dataRow[0].ToString());
                vendor.SetAttributeValue("name", dataRow[1].ToString());
                vendor.SetAttributeValue("assemblyname", dataRow[2].ToString());
                vendor.SetAttributeValue("classname", dataRow[3].ToString());
                vendor.SetAttributeValue("proxyassemblyname", dataRow[4].ToString());
                vendor.SetAttributeValue("proxyclassname", dataRow[5].ToString());
                vendor.SetAttributeValue("isactive", CommonFunctions.ConvertToBool(dataRow[6].ToString(), true));
            }

            DataAccessLayer.DataAccessLayer.SaveVendors();

            MessageBox.Show("Save Successfull.", CommonFunctions.GetCaption(), MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
