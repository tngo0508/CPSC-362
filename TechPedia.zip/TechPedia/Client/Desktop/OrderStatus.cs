﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using DevExpress.XtraEditors.Repository;
using App.TechPedia.DataAccessLayer;
using App.TechPedia.Common;
namespace App.TechPedia
{
    public partial class OrderStatus : Form
    {
        public OrderStatus()
        {
            InitializeComponent();
        }

        private RepositoryItemHyperLinkEdit m_Edit;

        private void OrderStatus_Load(object sender, EventArgs e)
        {
            CommonFunctions.SetFormInfo(this);

            FillOrderList();
        }

        private void FillOrderList()
        {
            XElement orderList = DataAccessLayer.DataAccessLayer.GetOrderList();
            IEnumerable<XElement> items = orderList.Elements("item");

            lstOrders.Items.Clear();
            foreach (XElement order in items)
            {
                string orderID = order.GetAttribute("order");
                lstOrders.Items.Add(orderID);
            }

            if (lstOrders.Items.Count > 0)
                lstOrders.SelectedIndex = 0;
        }

        private void lstOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            XElement orderElement = DataAccessLayer.DataAccessLayer.GetOrder(lstOrders.SelectedItem.ToString().Trim());

            IEnumerable<XElement> orderItemList = orderElement.Elements("item");
            IEnumerable<XElement> vendorList = DataAccessLayer.DataAccessLayer.GetVendors().Elements("vendor");

            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("VendorID", typeof(string));
            dataTable.Columns.Add("Vendor", typeof(string));
            dataTable.Columns.Add("Item ID", typeof(string));
            dataTable.Columns.Add("Name", typeof(string));
            dataTable.Columns.Add("Price", typeof(string));
            dataTable.Columns.Add("Description", typeof(string));
            dataTable.Columns.Add("Qty", typeof(string));
            dataTable.Columns.Add("Status", typeof(string));
            dataTable.Columns.Add("CancelOrder", typeof(string));

            foreach (XElement orderItem in orderItemList)
            {
                DataRow dataRow = dataTable.NewRow();

                XElement vendor = vendorList.FirstOrDefault(pred => pred.GetAttribute("id").Trim().ToUpper() == orderItem.GetAttribute("vendorid").Trim().ToUpper());

                if (vendor != null)
                {
                    IProxy proxy = CommonFunctions.GetVendorProxy(vendor);

                    if (proxy != null)
                    {
                        XElement productItem = proxy.GetItem(orderItem.GetAttribute("itemid"));

                        dataRow[0] = orderItem.GetAttribute("vendorid");
                        dataRow[1] = vendor.GetAttribute("name");
                        dataRow[2] = orderItem.GetAttribute("itemid");
                        dataRow[3] = productItem.GetAttribute("name");
                        dataRow[4] = orderItem.GetAttribute("price");
                        dataRow[5] = productItem.GetAttribute("description");
                        dataRow[6] = orderItem.GetAttribute("qty");
                        dataRow[7] = proxy.QueryOrderStatus(lstOrders.SelectedItem.ToString(), orderItem.GetAttribute("itemid"));
                        if (dataRow[7].ToString().Trim().ToUpper() == ("Order Cancelled").ToUpper())
                            dataRow[8] = "Cancelled";
                        else
                            dataRow[8] = "Cancel Order";

                        dataTable.Rows.Add(dataRow);
                    }
                }
            }

            gridControl1.DataSource = dataTable;

            gridView1.Columns[0].Visible = false;
            gridView1.Columns[1].OptionsColumn.AllowEdit = false;
            gridView1.Columns[2].OptionsColumn.AllowEdit = false;
            gridView1.Columns[3].OptionsColumn.AllowEdit = false;
            gridView1.Columns[4].OptionsColumn.AllowEdit = false;
            gridView1.Columns[5].OptionsColumn.AllowEdit = false;
            gridView1.Columns[6].OptionsColumn.AllowEdit = false;
            gridView1.Columns[7].OptionsColumn.AllowEdit = false;

            gridControl1.Refresh();

            m_Edit = new RepositoryItemHyperLinkEdit();
            m_Edit.Click += m_Edit_Click;
            gridView1.Columns[8].ColumnEdit = m_Edit;

            XElement otherInfo = orderElement.Element("otherinfo");
            string shippingFormat = otherInfo.GetAttribute("shippingformat");
            if (shippingFormat == "1")
            {
                shippingFormat = "$15 (5-7 days)";
            }
            else if (shippingFormat == "2")
            {
                shippingFormat = "$7.00 (3-5 days)";
            }
            else
            {
                shippingFormat = "Free Shipping";
            }

            StringBuilder sB = new StringBuilder();
            sB.Append("Shipping format : " + shippingFormat + Environment.NewLine);
            sB.Append("Shipping Address : " + otherInfo.GetAttribute("address") + Environment.NewLine);
            sB.Append("Shipping City : " + otherInfo.GetAttribute("city") + Environment.NewLine);
            sB.Append("Shipping State : " + otherInfo.GetAttribute("state") + Environment.NewLine);
            sB.Append("Shipping ZipCode : " + otherInfo.GetAttribute("zipcode") + Environment.NewLine);
            sB.Append(Environment.NewLine + Environment.NewLine);
            sB.Append("Payment Card Type : " + otherInfo.Element("paymentinfo").GetAttribute("type") + Environment.NewLine);
            sB.Append("Payment Card Expiry Date : " + otherInfo.Element("paymentinfo").GetAttribute("expdate") + Environment.NewLine);
            sB.Append("Payment Card Name : " + otherInfo.Element("paymentinfo").GetAttribute("id") + Environment.NewLine);
            sB.Append("Payment Card Holder Name : " + otherInfo.Element("paymentinfo").GetAttribute("name") + Environment.NewLine);
            sB.Append("Payment Card Number : " + otherInfo.Element("paymentinfo").GetAttribute("number") + Environment.NewLine);
            sB.Append("Payment Card Billing Address 1 : " + otherInfo.Element("paymentinfo").GetAttribute("address1") + Environment.NewLine);
            sB.Append("Payment Card Billing Address 2 : " + otherInfo.Element("paymentinfo").GetAttribute("address2") + Environment.NewLine);
            sB.Append("Payment Card City : " + otherInfo.Element("paymentinfo").GetAttribute("city") + Environment.NewLine);
            sB.Append("Payment Card State : " + otherInfo.Element("paymentinfo").GetAttribute("state") + Environment.NewLine);
            sB.Append("Payment Card ZipCode : " + otherInfo.Element("paymentinfo").GetAttribute("zip") + Environment.NewLine);

            txtDescription.Text = sB.ToString();
        }

        void m_Edit_Click(object sender, EventArgs e)
        {
            string orderID = lstOrders.SelectedItem.ToString().Trim();
            DataRow dataRow = gridView1.GetFocusedDataRow();
            string item = dataRow[7].ToString();

            if (item.Trim().ToUpper() == "Order Received".Trim().ToUpper())
            {
                int selectedIndex = lstOrders.SelectedIndex;
                IEnumerable<XElement> vendorList = DataAccessLayer.DataAccessLayer.GetVendors().Elements("vendor");
                string vendorID = dataRow[0].ToString();
                string itemID = dataRow[2].ToString();

                //  Cancel the order in local db.
                DataAccessLayer.DataAccessLayer.CancelOrder(orderID, vendorID, itemID);

                //  Place the cancellation to the vendor.
                XElement vendor = vendorList.FirstOrDefault(pred => pred.GetAttribute("id").Trim().ToUpper() == vendorID.Trim().ToUpper());

                if (vendor != null)
                {
                    IProxy proxy = CommonFunctions.GetVendorProxy(vendor);
                    proxy.CancelOrder(orderID, itemID);
                }

                FillOrderList();

                if (lstOrders.Items.Count > selectedIndex)
                    lstOrders.SelectedIndex = selectedIndex;

                MessageBox.Show("Order Cancelled.", CommonFunctions.GetCaption(), MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Order Already Processed/Cancelled and cannot cancel order.", CommonFunctions.GetCaption(), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
